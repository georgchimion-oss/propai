#!/bin/bash
# Run this script once to download all images for offline use
# Usage: chmod +x download-images.sh && ./download-images.sh

mkdir -p public/images

echo "Downloading images from Pexels..."

curl -sL -o public/images/hero-bg.jpeg "https://images.pexels.com/photos/3155666/pexels-photo-3155666.jpeg?auto=compress&cs=tinysrgb&w=1920" && echo "✓ hero-bg.jpeg"
curl -sL -o public/images/howitworks-bg.jpeg "https://images.pexels.com/photos/8293778/pexels-photo-8293778.jpeg?auto=compress&cs=tinysrgb&w=1920" && echo "✓ howitworks-bg.jpeg"
curl -sL -o public/images/market-bg.jpeg "https://images.pexels.com/photos/1438832/pexels-photo-1438832.jpeg?auto=compress&cs=tinysrgb&w=1920" && echo "✓ market-bg.jpeg"
curl -sL -o public/images/problem-statement.jpeg "https://images.pexels.com/photos/6953853/pexels-photo-6953853.jpeg?auto=compress&cs=tinysrgb&w=800" && echo "✓ problem-statement.jpeg"
curl -sL -o public/images/compliance.jpeg "https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=800" && echo "✓ compliance.jpeg"
curl -sL -o public/images/cta-bg.jpeg "https://images.pexels.com/photos/1134166/pexels-photo-1134166.jpeg?auto=compress&cs=tinysrgb&w=1920" && echo "✓ cta-bg.jpeg"

echo ""
echo "Done! All images downloaded to public/images/"
