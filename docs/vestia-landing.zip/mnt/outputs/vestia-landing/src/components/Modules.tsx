import { Wrench, Shield, DollarSign, UserCheck, FileText, Users } from 'lucide-react';

const modules = [
  {
    icon: Wrench,
    name: 'Vestia Triage',
    description: 'AI-powered maintenance triage and intelligent dispatch',
    color: '#ef4444',
    features: ['Automated categorization', 'Priority scoring', 'Vendor routing'],
  },
  {
    icon: Shield,
    name: 'Vestia Comply',
    description: 'SB 4-D compliance tracking and milestone management',
    color: '#2dd4bf',
    features: ['SIRS tracking', 'Reserve monitoring', 'Board alerts'],
  },
  {
    icon: DollarSign,
    name: 'Vestia Collect',
    description: 'Automated rent collection and payment processing',
    color: '#c9a96e',
    features: ['Auto-pay setup', 'Late fee automation', 'Reconciliation'],
  },
  {
    icon: UserCheck,
    name: 'Vestia Screen',
    description: 'Tenant screening automation with AI-powered insights',
    color: '#a855f7',
    features: ['Credit checks', 'Background verification', 'Risk scoring'],
  },
  {
    icon: FileText,
    name: 'Vestia Docs',
    description: 'Intelligent lease document generation and management',
    color: '#3b82f6',
    features: ['Template library', 'E-signature', 'Version control'],
  },
  {
    icon: Users,
    name: 'Vestia Vendor',
    description: 'Vendor RFP management and bid comparison',
    color: '#f97316',
    features: ['RFP builder', 'Bid analysis', 'Performance tracking'],
  },
];

export function Modules() {
  return (
    <section id="modules" className="bg-[#f8f7f4] py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl text-[#07070c] mb-4">
            Six modules. One platform.
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Purpose-built AI tools that handle the full property management lifecycle
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {modules.map((module) => (
            <div
              key={module.name}
              className="group bg-white p-8 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 cursor-pointer border border-gray-200"
            >
              <div
                className="w-14 h-14 rounded-lg flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110"
                style={{ backgroundColor: `${module.color}20` }}
              >
                <module.icon className="w-7 h-7" style={{ color: module.color }} />
              </div>

              <h3 className="font-serif text-2xl text-[#07070c] mb-3">{module.name}</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">{module.description}</p>

              <div className="flex flex-wrap gap-2">
                {module.features.map((feature) => (
                  <span
                    key={feature}
                    className="text-xs px-3 py-1.5 bg-gray-100 text-gray-700 rounded-full"
                  >
                    {feature}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
