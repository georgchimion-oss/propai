import { Smartphone, Brain, CheckCircle } from 'lucide-react';

const steps = [
  {
    icon: Smartphone,
    title: 'Report',
    description: 'Tenant submits issue via text, email, or app',
  },
  {
    icon: Brain,
    title: 'AI Triage',
    description: 'Vestia categorizes, prioritizes, assigns',
  },
  {
    icon: CheckCircle,
    title: 'Resolve',
    description: 'Vendor dispatched, work tracked, tenant updated',
  },
];

export function HowItWorks() {
  return (
    <section className="relative py-24 overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            'url(/images/howitworks-bg.jpeg)',
        }}
      >
        <div className="absolute inset-0 bg-[#07070c]/85"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl text-white mb-4">
            How it works
          </h2>
          <p className="text-gray-300 text-lg">
            From report to resolution in three intelligent steps
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 md:gap-4">
          {steps.map((step, index) => (
            <div key={step.title} className="relative">
              <div className="bg-white/5 backdrop-blur-md border border-white/10 p-8 hover:bg-white/10 transition-all duration-300">
                <div className="flex items-center justify-center w-16 h-16 bg-[#c9a96e] rounded-full mb-6 mx-auto">
                  <step.icon className="w-8 h-8 text-[#07070c]" />
                </div>

                <h3 className="font-serif text-2xl text-white text-center mb-3">
                  {step.title}
                </h3>
                <p className="text-gray-300 text-center leading-relaxed">
                  {step.description}
                </p>
              </div>

              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-4 w-8 h-0.5 bg-[#c9a96e]/30"></div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
