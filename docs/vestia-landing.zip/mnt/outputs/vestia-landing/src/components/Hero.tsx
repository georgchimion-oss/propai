import { Play } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            'url(/images/hero-bg.jpeg)',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-[#07070c] via-[#07070c]/60 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 px-4 py-2 rounded-full mb-8">
          <div className="w-2 h-2 bg-[#2dd4bf] rounded-full animate-pulse"></div>
          <span className="text-sm text-white/90">AI-Powered Property Management</span>
        </div>

        <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl text-white mb-6 leading-tight">
          The future of property intelligence
        </h1>

        <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto mb-8 leading-relaxed">
          Six AI modules purpose-built for South Florida condo associations. From
          maintenance triage to compliance tracking — one platform, zero spreadsheets.
        </p>

        <div className="flex flex-wrap justify-center gap-4 mb-10">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 px-5 py-3 rounded-full">
            <span className="text-white font-medium">27/30 AI Disruption Score</span>
          </div>
          <div className="bg-white/10 backdrop-blur-md border border-white/20 px-5 py-3 rounded-full">
            <span className="text-white font-medium">38% of cycles automatable</span>
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-4">
          <button className="bg-[#c9a96e] text-[#07070c] px-8 py-4 text-base font-medium hover:bg-[#d4b57f] transition-all duration-300 hover:shadow-2xl hover:shadow-[#c9a96e]/40 hover:scale-105">
            See the Platform
          </button>
          <button className="border-2 border-white text-white px-8 py-4 text-base font-medium hover:bg-white/10 transition-all duration-300 flex items-center gap-2">
            <Play className="w-5 h-5" />
            Watch Demo
          </button>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#07070c] to-transparent"></div>
    </section>
  );
}
