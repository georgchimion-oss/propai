import { Check } from 'lucide-react';

const features = [
  'Milestone inspections',
  'SIRS tracking',
  '15-year retention',
  'Reserve funding',
  'Board notifications',
  'CTMH reporting',
];

export function Compliance() {
  return (
    <section id="compliance" className="bg-[#f8f7f4] py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="bg-gradient-to-br from-[#2dd4bf]/10 to-[#2dd4bf]/5 border-2 border-[#2dd4bf]/20 p-8 md:p-12">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block bg-[#2dd4bf]/20 text-[#2dd4bf] px-4 py-2 text-sm font-medium mb-6">
                POST-SURFSIDE COMPLIANCE
              </div>

              <h2 className="font-serif text-4xl md:text-5xl text-[#07070c] mb-6">
                SB 4-D Compliance Built In
              </h2>

              <p className="text-gray-700 text-lg leading-relaxed mb-8">
                The Florida Building Safety Act changed everything. Vestia Comply
                keeps your association ahead of requirements and protects board
                members from personal liability.
              </p>

              <div className="grid sm:grid-cols-2 gap-4">
                {features.map((feature) => (
                  <div key={feature} className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-6 h-6 bg-[#2dd4bf] rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>

              <div className="mt-8 p-4 bg-[#2dd4bf]/10 border-l-4 border-[#2dd4bf]">
                <p className="text-sm text-gray-700 font-medium">
                  Board members are personally liable for non-compliance
                </p>
              </div>
            </div>

            <div className="relative h-[400px] md:h-[500px]">
              <img
                src="/images/compliance.jpeg"
                alt="Compliance dashboard"
                className="w-full h-full object-cover shadow-2xl"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
