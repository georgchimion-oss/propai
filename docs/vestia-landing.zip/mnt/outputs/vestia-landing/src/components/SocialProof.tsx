export function SocialProof() {
  return (
    <section className="bg-[#07070c] py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center">
          <p className="text-gray-400 text-sm uppercase tracking-wider mb-8">
            Trusted by South Florida property managers
          </p>

          <div className="flex flex-wrap justify-center items-center gap-12 opacity-50">
            <div className="text-2xl font-serif tracking-wider text-white">CAI</div>
            <div className="text-2xl font-serif tracking-wider text-white">SFPMA</div>
            <div className="text-2xl font-serif tracking-wider text-white">NARPM</div>
          </div>
        </div>

        <div className="mt-16 max-w-3xl mx-auto bg-white/5 backdrop-blur-md border border-white/10 p-12">
          <p className="font-serif text-2xl text-white italic mb-6 leading-relaxed">
            "Property management testimonial will be featured here once we have early
            adopters sharing their experience with Vestia."
          </p>
          <div className="text-gray-400">
            <div className="font-medium text-white">Coming Soon</div>
            <div className="text-sm">First 50 associations</div>
          </div>
        </div>
      </div>
    </section>
  );
}
