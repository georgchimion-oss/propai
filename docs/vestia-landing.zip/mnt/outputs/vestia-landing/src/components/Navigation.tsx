import { useState, useEffect } from 'react';

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#07070c]/90 backdrop-blur-lg shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="text-2xl font-serif tracking-[0.3em] text-white">
          VESTIA
        </div>

        <div className="hidden md:flex items-center gap-8">
          <a href="#platform" className="text-sm text-gray-300 hover:text-white transition-colors">
            Platform
          </a>
          <a href="#modules" className="text-sm text-gray-300 hover:text-white transition-colors">
            Modules
          </a>
          <a href="#compliance" className="text-sm text-gray-300 hover:text-white transition-colors">
            Compliance
          </a>
          <a href="#about" className="text-sm text-gray-300 hover:text-white transition-colors">
            About
          </a>
        </div>

        <button className="bg-[#c9a96e] text-[#07070c] px-6 py-2.5 text-sm font-medium hover:bg-[#d4b57f] transition-all duration-300 hover:shadow-lg hover:shadow-[#c9a96e]/30">
          Request Demo
        </button>
      </div>
    </nav>
  );
}
