import { ArrowRight } from 'lucide-react';

export function CTA() {
  return (
    <section className="relative py-32">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            'url(/images/cta-bg.jpeg)',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-[#07070c] via-[#07070c]/70 to-[#07070c]/40"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <h2 className="font-serif text-4xl md:text-6xl text-white mb-6">
          Ready to modernize your property management?
        </h2>

        <p className="text-xl text-gray-300 mb-10">
          Free for the first 50 associations
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-lg mx-auto">
          <input
            type="email"
            placeholder="Enter your email"
            className="flex-1 px-6 py-4 bg-white/10 backdrop-blur-md border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#c9a96e]"
          />
          <button className="bg-[#c9a96e] text-[#07070c] px-8 py-4 font-medium hover:bg-[#d4b57f] transition-all duration-300 flex items-center justify-center gap-2 hover:shadow-2xl hover:shadow-[#c9a96e]/40 whitespace-nowrap">
            Get Early Access
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        <p className="text-sm text-gray-400 mt-6">
          Join the waitlist. No credit card required.
        </p>
      </div>
    </section>
  );
}
