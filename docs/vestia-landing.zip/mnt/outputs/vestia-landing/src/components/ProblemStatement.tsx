export function ProblemStatement() {
  return (
    <section className="bg-[#07070c] py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative h-[400px] md:h-[500px] overflow-hidden">
            <img
              src="/images/problem-statement.jpeg"
              alt="Property manager overwhelmed with paperwork"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#07070c] via-transparent to-transparent"></div>
          </div>

          <div>
            <h2 className="font-serif text-4xl md:text-5xl text-white mb-8">
              Property managers are drowning.
            </h2>

            <div className="space-y-6">
              <div className="border-l-2 border-[#c9a96e] pl-6">
                <p className="text-gray-300 text-lg leading-relaxed">
                  Average PM still coordinates via email and phone calls
                </p>
              </div>
              <div className="border-l-2 border-[#c9a96e] pl-6">
                <p className="text-gray-300 text-lg leading-relaxed">
                  $19.5B in annual FL assessments managed on spreadsheets
                </p>
              </div>
              <div className="border-l-2 border-[#c9a96e] pl-6">
                <p className="text-gray-300 text-lg leading-relaxed">
                  Board members personally liable for compliance failures
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
