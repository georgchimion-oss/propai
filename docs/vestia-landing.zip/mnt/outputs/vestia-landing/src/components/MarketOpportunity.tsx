const stats = [
  { value: '$88B', label: 'Global PropTech market' },
  { value: '49,000', label: 'FL associations' },
  { value: '$19.5B', label: 'Annual assessments' },
  { value: '38%', label: 'Ripe for disruption' },
];

export function MarketOpportunity() {
  return (
    <section className="relative py-24">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            'url(/images/market-bg.jpeg)',
        }}
      >
        <div className="absolute inset-0 bg-[#07070c]/80"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <h2 className="font-serif text-4xl md:text-5xl text-white text-center mb-16">
          South Florida is the perfect market.
        </h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="bg-white/5 backdrop-blur-md border border-white/10 p-8 text-center hover:bg-white/10 transition-all duration-300 hover:scale-105"
            >
              <div className="font-serif text-5xl text-[#c9a96e] mb-3">
                {stat.value}
              </div>
              <div className="text-gray-300 text-sm uppercase tracking-wider">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
