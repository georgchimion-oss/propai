import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { ProblemStatement } from './components/ProblemStatement';
import { Modules } from './components/Modules';
import { HowItWorks } from './components/HowItWorks';
import { MarketOpportunity } from './components/MarketOpportunity';
import { Compliance } from './components/Compliance';
import { SocialProof } from './components/SocialProof';
import { CTA } from './components/CTA';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-[#07070c]">
      <Navigation />
      <Hero />
      <ProblemStatement />
      <Modules />
      <HowItWorks />
      <MarketOpportunity />
      <Compliance />
      <SocialProof />
      <CTA />
      <Footer />
    </div>
  );
}

export default App;
