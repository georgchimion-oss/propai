import { useState, useEffect } from 'react';

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-glass border-b border-border'
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto flex items-center justify-between py-4 px-6 lg:px-8">
        <a href="#" className="font-serif text-2xl tracking-[0.3em] font-semibold text-foreground">
          VESTIA
        </a>

        <div className="hidden md:flex items-center gap-8">
          {['Platform', 'Modules', 'Compliance', 'About'].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              className="text-sm font-sans text-muted-foreground hover:text-foreground transition-colors duration-300 tracking-wide"
            >
              {item}
            </a>
          ))}
        </div>

        <button className="gradient-gold text-primary-foreground font-sans text-sm font-semibold px-6 py-2.5 rounded-md hover:brightness-110 transition-all duration-300 active:scale-[0.97] tracking-wide">
          Request Demo
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
